import re
import requests
import psycopg2
from bs4 import BeautifulSoup

conn = psycopg2.connect("user = postgres password = 18031j0068")
current = conn.cursor()
name = []
with open("tickers.txt",'r') as file:
    for x in file:
        n = x.split("::")
        name.append(n[0].rstrip())
#print(name)

for add in name:
   addData = []
   im = 1
   site = open('D:/Python/Project/TrickersDir/'+add+'/profile.html')
   soup = BeautifulSoup(site,'html.parser')

   name1 = soup.find(class_='Fz(m) Mb(10px)')

   div = soup.find(class_='Mb(25px)')
   para = div.find_all('p')
   ahref = div.find_all('a')

   for rows in para:
      r = re.split("http://",rows.get_text())
      if im == 1:
         addData.append(r[0])
         im = 2
   for row in ahref:
      addData.append(row.get_text())

   slp = re.split("Industry:Â\xa0|Sector:Â\xa0|Full-time employees:Â\xa0",r[0])
   addData.append(slp[1])
   addData.append(slp[2])
   addData.append(slp[3])
   #print(addData)
   name = name1.get_text()
   phone = addData[1].translate({ord(i): None for i in addData[2]})
   address = addData[0].strip(phone)
   web = addData[2]
   sector = addData[3]
   industry = addData[4]
   employees = addData[5]
   #print("1 "+name)
   #print("2 "+address)
   #print("3 "+phone)
   #print("4 "+web)
   #print("5 "+sector)
   #print("6 "+industry)
   #print("7 "+employees)
   profile =  "INSERT INTO Profile (Ticker,Name,Address,Phonenum,Website,Sector,Industry,Full_Time) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
   data = (add,name,address,phone,web,sector,industry,employees)
   current.execute(profile,data)

conn.commit()
conn.close()
current.close()
print("Successfully Inserted")



