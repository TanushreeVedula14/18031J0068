import requests
import re
import psycopg2
from bs4 import BeautifulSoup

conn = psycopg2.connect("user = postgres password = 18031j0068")
current = conn.cursor()

ticker = []
tickerName = []
with open("tickers.txt",'r') as file:
    for x in file:
        n = x.split("::")
        ticker.append(n[0].rstrip())
        tickerName.append(n[1].rstrip())
# print(ticker)
# print(tickerName)

f = open("StopWords.txt","r")
file = f.read()

## Enter question
question = input("Enter question : ")
ques = question.split(" ")
#print(ques)

##Split question and remove stop words
new_ques = []
for i in range(0,len(ques)):
    if (ques[i] == 'how' and ques[i+1] == 'many'):
        new_ques.append(ques[i]+" "+ques[i+1])
    elif (ques[i] == 'how' and ques[i+1] == 'much'):
        new_ques.append(ques[i]+" "+ques[i+1])
    elif '"' + ques[i] + '"' not in file:
        new_ques.append(ques[i])
#print(new_ques)

## Get ticker name
for qu in ques:
    #print(qu)
    for tn in range(len(tickerName)):
        t = tickerName[tn].split(" ")
        if (qu == t[0]):
            tName = ticker[tn]
#print(tName)

## create nested dictionary
dictionary = {'statistics':{'sno':'None','ticker':'what','marketcap':'what,how much','enterprise_value':'what,how much','return_on_assets':'how much,what','total_cash':'what','operating_cash_flow':'what','levered_free_cash_flow':'what','total_debt':'what','current_ratio':'what,how much','gross_profit':'what,how much','profit_margin':'what,how much'},
                'profile':{'sno':'None','ticker':'what','name':'what','address':'where,what','phonenum':'what','website':'what','sector':'what,which','industry':'what,which','full_time':'how many,what','bus_summ':'what'},
                'finances':{'sno':'None','ticker':'what','total_Revenue':'how much,what','cost_of_revenue':'how much,what','income_before_tax':'how much,what','net_income':'what'}}
#print(dictionary.values())

## find attributes from dictionary
queryList = []
for word in new_ques:
    #print(word)
    for type in dictionary:
        #print(word+"==="+type)
        for key in dictionary[type]:
            #print(word+"==="+type+"==="+key)
            if (key.__contains__(word)):
                #print(key)
                queryList.append(key+"--->"+type)
#print(queryList[0])
q = queryList[0].split("--->")
attribute = q[0]
#print(attribute)
tableName = q[1]
#print(tableName)

##generate simple query
query = "SELECT "+attribute+" FROM "+tableName+" WHERE ticker = "+"'{}'".format(tName)+";"
#print(query)
current.execute(query)
data = current.fetchone()
print(data)

conn.commit()
conn.close()
current.close()
















