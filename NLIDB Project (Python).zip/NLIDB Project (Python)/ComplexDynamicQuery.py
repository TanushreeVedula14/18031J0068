import requests
import re
import psycopg2
from bs4 import BeautifulSoup

conn = psycopg2.connect("user = postgres password = 18031j0068")
current = conn.cursor()

ticker = []
tickerName = []
with open("tickers.txt",'r') as file:
    for x in file:
        n = x.split("::")
        ticker.append(n[0].rstrip())
        tickerName.append(n[1].rstrip())
# print(ticker)
# print(tickerName)

f = open("StopWords.txt","r")
file = f.read()

## Enter question
question = input("Enter question : ")
ques = question.split(" ")
#print(ques)

##Split question and remove stop words
new_ques = []
for i in range(0,len(ques)):
    if (ques[i] == 'how' and ques[i+1] == 'many'):
        new_ques.append(ques[i]+" "+ques[i+1])
    elif (ques[i] == 'how' and ques[i+1] == 'much'):
        new_ques.append(ques[i]+" "+ques[i+1])
    elif '"' + ques[i] + '"' not in file:
        new_ques.append(ques[i])
#print(new_ques)

# tName = ""
# if tName == " ":
## Get ticker name
for qu in ques:
    #print(qu)
    for tn in range(len(tickerName)):
        t = tickerName[tn].split(" ")
        if (qu == t[0]):
            tName = ticker[tn]
#print(tName)

## create nested dictionary
dictionary = {'statistics':{'sno':'None','ticker':'what','marketcap':'what,how much','enterprise_value':'what,how much','return_on_assets':'how much,what','total_cash':'what','operating_cash_flow':'what','levered_free_cash_flow':'what','total_debt':'what','current_ratio':'what,how much','gross_profit':'what,how much','profit_margin':'what,how much'},
                'profile':{'sno':'None','ticker':'what','name':'what','address':'where,what','phonenum':'what','website':'what','sector':'what,which','industry':'what,which','full_time':'how many,what','bus_summ':'what'},
                'finances':{'sno':'None','ticker':'what','total_Revenue':'how much,what','cost_of_revenue':'how much,what','income_before_tax':'how much,what','net_income':'what'}}
#print(dictionary.values())

## find attributes from dictionary
queryList = []
for word in range(len(new_ques)):
    #print(word)
    for type in dictionary:
        #print(word+"==="+type)
        for key in dictionary[type]:
            #print(word+"==="+type+"==="+key)
            if (key.__contains__(new_ques[word]) and key.__contains__(new_ques[word+1])):
                #print(key)
                queryList.append(key+"--->"+type)
            elif (key.__contains__(new_ques[word])):
                queryList.append(key+"--->"+type)
#print(queryList[0])
q = queryList[0].split("--->")
attribute = str(q[0])
#print(attribute)
tableName = str(q[1])
#print(tableName)

##generate complex query
for qu in range(len(new_ques)):
    if new_ques[qu] == 'complete' and new_ques[qu + 1] == 'details':
        for qu in range(len(new_ques)):
            if new_ques[qu] == 'maximum':
                query = "SELECT * FROM profile WHERE ticker = (SELECT ticker FROM " + tableName + " WHERE marketcap = (SELECT MAX(" + attribute + ") FROM " + tableName + "));"
                # print(query)
                current.execute(query)
                data = current.fetchall()
                print(data)
            elif new_ques[qu] == 'minimum':
                query = "SELECT * FROM profile WHERE ticker = (SELECT ticker FROM " + tableName + " WHERE marketcap = (SELECT MIN(" + attribute + ") FROM " + tableName + "));"
                # print(query)
                current.execute(query)
                data = current.fetchall()
                print(data)
    else:
        if (new_ques[qu] == 'highest' or new_ques[qu] == 'lowest'):
            if new_ques[qu] == 'highest':
                query = "SELECT ticker FROM " + tableName + " WHERE " + attribute + " = (SELECT MAX(" + attribute + ") FROM " + tableName + ");"
                # print(query)
                current.execute(query)
                data = current.fetchone()
                data1 = data[0]
            elif new_ques[qu] == 'lowest':
                query = "SELECT ticker FROM " + tableName + " WHERE " + attribute + " = (SELECT MIN(" + attribute + ") FROM " + tableName + ");"
                # print(query)
                current.execute(query)
                data = current.fetchone()
                data1 = data[0]

            for d in range(len(ticker)):
                if ticker[d] == data1:
                    print(tickerName[d])

conn.commit()
conn.close()
current.close()