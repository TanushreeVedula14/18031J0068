import re
import requests
import psycopg2
from bs4 import BeautifulSoup


conn = psycopg2.connect("user = postgres password = 18031j0068")
current = conn.cursor()
name = []
with open("tickers.txt",'r') as file:
    for x in file:
        n = x.split("::")
        name.append(n[0].rstrip())
#print(name)

for add in name:
    #print(add)
    listToFindData = ["Total revenue","Cost of revenue","Income before tax","Net income"]
    listData = []
    site = open('D:/Python/Project/TrickersDir/'+add+'/financial.html')
    soup = BeautifulSoup(site,'html.parser')

    table = soup.find(class_='Mt(10px) Ovx(a) W(100%)')
    lines = [th.get_text() for th in table.find("tr").find_all("th")]
    for row in table.find_all("tr")[0:]:
        info = [td.get_text() for td in row.find_all("td")]
        if len(info)>3:
            if listToFindData.__contains__(info[0]):
                listData.append(info[1])
                #print(info[0]+" -----> "+info[1])
    #print(listData)
    finance = "INSERT INTO Finances (Ticker,Total_Revenue,Cost_of_Revenue,Income_Before_Tax,Net_Income) VALUES (%s,%s,%s,%s,%s)"
    data = (add,listData[0],listData[1],listData[2],listData[3])
    current.execute(finance,data)
    #print("-------------------------------------------------------------------------")

conn.commit()
conn.close()
current.close()
print("Successfully Inserted")