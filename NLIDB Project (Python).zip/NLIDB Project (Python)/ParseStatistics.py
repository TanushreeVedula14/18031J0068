import re
import requests
import psycopg2
from bs4 import BeautifulSoup

conn = psycopg2.connect("user = postgres password = 18031j0068")
current = conn.cursor()
name = []
with open("tickers.txt",'r') as file:
    for x in file:
        n = x.split("::")
        name.append(n[0].rstrip())
#print(name)

for add in name:
    #print(add)
    listToFindData = ["Market cap (intra-day) 5","Enterprise value 3","Profit margin ","Return on assets (ttm)","Gross profit (ttm)","Total cash (mrq)","Total debt (mrq)","Current ratio (mrq)",
                      "Operating cash flow (ttm)","Levered free cash flow (ttm)"]
    listData = []
    site = open('D:/Python/Project/TrickersDir/'+add+'/statistics.html')
    soup = BeautifulSoup(site,'html.parser')

    table = soup.find(class_='Fl(start) W(50%) smartphone_W(100%)')
    lines = [th.get_text() for th in table.find("tr").find_all("th")]
    for row in table.find_all("tr")[0:]:
        info = [td.get_text() for td in row.find_all("td")]
        #print(info)
        if listToFindData.__contains__(info[0]):
            listData.append(info[1])
    #print(listToFindData)
    #print(listData)
    #x = 0
    #for i in listData:
        #print(x)
        #print(i)
        #x += 1
    statistics = "INSERT INTO Statistics (Ticker,Marketcap,Enterprise_Value,Profit_Margin,Return_On_Assets,Gross_Profit,Total_Cash,Total_Debt,Current_Ratio,Operating_Cash_Flow,Levered_Free_Cash_Flow) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    data = (add,listData[0],listData[1],listData[2],listData[3],listData[4],listData[5],listData[6],listData[7],listData[8],listData[9])
    current.execute(statistics,data)
    #print("-------------------------------------------------------------------------")

conn.commit()
conn.close()
current.close()
print("Successfully Inserted")

