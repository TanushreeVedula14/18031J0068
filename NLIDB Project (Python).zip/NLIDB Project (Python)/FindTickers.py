import requests
import re
from bs4 import BeautifulSoup

# parse and save Tickers and Tickers name in text file
site = requests.get('https://finance.yahoo.com/trending-tickers')
soup = BeautifulSoup(site.text,'html.parser')

table = soup.find("table")
lines = [th.get_text() for th in table.find("tr").find_all("th")]
file = open("tickers.txt",'w')
for row in table.find_all("tr")[1:7]:
    info = [td.get_text() for td in row.find_all("td")]
    tickers = info[0]
    tickers = tickers.strip()
    cName = info[1]
    cName = cName.strip()
    data = tickers+"::"+cName+"\n"
    print(data)
    file.write(data)
file.close()
    
