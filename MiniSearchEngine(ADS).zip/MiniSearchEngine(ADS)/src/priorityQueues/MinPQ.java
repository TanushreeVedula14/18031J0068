package priorityQueues;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

 class PQ<Key> implements Iterable<Key> 
 {
    private Key[] pq;          
    private int n;          
    private Comparator<Key> comparator; 

    //constructors
    @SuppressWarnings("unchecked")
	public PQ(int maxsize) 
    {
        pq = (Key[]) new Object[maxsize + 1];
        n = 0;
    }
    public  PQ() 
    {
        this(1);
    }
    @SuppressWarnings("unchecked")
	public  PQ(int maxsize, Comparator<Key> comparator)
    {
        this.comparator = comparator;
        pq = (Key[]) new Object[maxsize + 1];
        n = 0;
    }
    public  PQ(Comparator<Key> comparator) 
    {
        this(1, comparator);
    } 
    @SuppressWarnings("unchecked")
	public  PQ(Key[] keys) 
    {
        n = keys.length;
        pq = (Key[]) new Object[keys.length + 1];
        for (int i = 0; i < n; i++)
        {
            pq[i+1] = keys[i];
        }
        for (int k = n/2; k >= 1; k--)
        {
            sink(k);
        }
        assert isMinHeap();
    }
    
    
    public boolean isEmpty() 
    {
        return n == 0;
    }
    
    
    public int size() 
    {
        return n;
    }
    
    
    public Key min() 
    {
        if (isEmpty()) 
        	throw new NoSuchElementException("Priority queue underflow");
        return pq[1];
    }
    
    
    @SuppressWarnings("unchecked")
	private void resize(int size) 
    {
        assert size > n;
        Key[] temp = (Key[]) new Object[size];
        for (int i = 1; i <= n; i++) 
        {
            temp[i] = pq[i];
        }
        pq = temp;
    }
    
    public void insert(Key x) 
    {
        
        if (n == pq.length - 1) 
        {
        	resize(2 * pq.length);
        }
       
        pq[++n] = x;
        swim(n);
        assert isMinHeap();
    }
    
    public Key delMin() 
    {
        if (isEmpty()) 
        {
        	throw new NoSuchElementException("Priority queue underflow");
        }
        
        Key min = pq[1];
        exch(1, n--);
        sink(1);
        pq[n+1] = null; 
        if ((n > 0) && (n == (pq.length - 1) / 4)) 
        {
        	resize(pq.length / 2);
        }
        assert isMinHeap();
        return min;
    }
    
    private void swim(int k) 
    {
        while (k > 1 && greater(k/2, k)) 
        {
            exch(k, k/2);
            k = k/2;
        }
    }

    private void sink(int k) 
    {
        while (2*k <= n) 
        {
            int j = 2*k;
            if (j < n && greater(j, j+1)) 
            {
            	j++;
            }
            if (!greater(k, j))
            {
            	break;
            }
            exch(k, j);
            k = j;
        }
    }
    
    @SuppressWarnings("unchecked")
	private boolean greater(int i, int j) 
    {
        if (comparator == null) 
        {
            return ((Comparable<Key>) pq[i]).compareTo(pq[j]) > 0;
        }
        else 
        {
            return comparator.compare(pq[i], pq[j]) > 0;
        }
    }

    private void exch(int i, int j)
    {
        Key swap = pq[i];
        pq[i] = pq[j];
        pq[j] = swap;
    }

    private boolean isMinHeap() 
    {
        return isMinHeap(1);
    }

    private boolean isMinHeap(int k) 
    {
        if (k > n) 
        {
        	return true;
        }
        int left = 2*k;
        int right = 2*k + 1;
        
        if (left  <= n && greater(k, left))
        {
        	return false;
        }
        if (right <= n && greater(k, right))
        {
        	return false;
        }
        return isMinHeap(left) && isMinHeap(right);
    }
    
    public Iterator<Key> iterator() 
    {
        return new HeapIterator();
    }

    private class HeapIterator implements Iterator<Key>
    {
        private  PQ<Key> pqk;
        
        public HeapIterator()
        {
            if (comparator == null)
            {
            	pqk = new  PQ<Key>(size());
            }
            else
            {
            	pqk = new  PQ<Key>(size(), comparator);
            }
            for (int i = 1; i <= n; i++)
            {
            	pqk.insert(pq[i]);
            }
        }

        public boolean hasNext()  
        { 
        	return !pqk.isEmpty();                     
        }
        
        public void remove()      
        { 
        	throw new UnsupportedOperationException();
        }

        public Key next()
        {
            if (!hasNext()) 
            {
            	throw new NoSuchElementException();
            }
            return pqk.delMin();
        }
   
    }
    
}


@SuppressWarnings("rawtypes")
public class MinPQ  <E extends Comparable<E>> implements PQueueADT
{
	 PQ<E> mp=new  PQ<E>();
	 
	@Override
	public E dequeue() 
	{
		return mp.delMin() ;
	} 

	@Override
	public int size() 
	{
		return mp.size( );
	}

	@Override
	public boolean is_empty()
	{
		if(size()==0)
			return true;
		return false;
	}

	@Override
	public E front() 
	{
		return mp.min() ;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void enqueue(Comparable value)
	{
		mp.insert((E) value);
	}

	public static void main(String args[]) throws NumberFormatException, IOException
	{
		MinPQ<String> p = new MinPQ<String>();
		PQ<String> pq = new PQ<String>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int ch;
		do
		{
			System.out.println("Priority Queue Operations.");
			System.out.println("1.Insert.\n2.Delete.\n3.Size.\n4.Front Element.");
			ch = Integer.parseInt(br.readLine());
			
			switch(ch)
			{
			case 1 : System.out.println("Enter element : ");
						String ele = br.readLine();
						p.enqueue(ele);
						break;
			case 2 : System.out.println(p.dequeue());
						break;
			case 3 : System.out.println(p.size());
						break;
			case 4 : System.out.println("Front element = "+p.front());
						break;
			default : System.out.println("Testing over.");
			 			break;
			 		
			}
		}while(ch < 5);
	}

}
