package priorityQueues;

public interface PQueueADT<E extends Comparable<E>> {
	
	public void enqueue(E value);
	public E dequeue();
	public int size();
	public boolean is_empty();
	public E front();

}
