package dictionary;

import java.util.Enumeration;
import java.util.Hashtable;

class Hashmap
{
	
	Hashtable<String, String> hm;
	
	public Hashmap() 
	{
		
		hm = new Hashtable<String,String>();
	}
		
	void insert(String key,String value)
	{
		if(!hm.containsKey(key))
		{
			value=value+"->"+1;
			hm.put(key,(String)value);
		}
		else
		{	
			if(hm.containsKey(key))
			{
				String str;
				int flag = 0;
				
				String str1 = hm.get(key);
				System.out.println("str1 = "+str1);
				String[] str2 = str1.split("-->");
				for(int i = 0;i < str2.length;i++)
				{
					String str3 = str2[i];
					System.out.println("str3 = "+str3);
					String[] str4 = str3.split("->");
					
					if(str4[0].equals((String)value))
					{
						flag=1;
						System.out.println("InnerInner = "+str4[0]);
						int count = Integer.parseInt(str4[1]);
						System.out.println("count = "+count);
						str4[1] = String.valueOf(++count);
						str = str4[0]+"->"+str4[1];
						hm.put(key,str);
					}
				}
				if(flag==0)// new Value 
				{
					
					value = value+"->"+1;
					str = str1+"-->"+(String)value;
					hm.put(key, str);
				}
			}
			else 
			{
				System.out.println("New Key");
				value = value+"->"+1;
				hm.put(key,(String)value);
			}
				
		}	/*newVal = value;
			String x = hm.get(key);
			newVal = x+"-->"+value;
			hm.replace(key, newVal);*/
		
	}
	
	
	void delete(String key)
	{
		hm.remove(key);
		
	}
	
	@SuppressWarnings("rawtypes")
	String[] getKeys() 
	{
		
		String[] k = new String[hm.size()];
		Enumeration<String> en = hm.keys();
		
		for(int i = 0;en.hasMoreElements();i++)
		{
			k[i] = en.nextElement();
		}
		return k;
	}
	
	String value(String key){
		
		 String value = hm.get(key);
		
		return value;
		
	}
	
}

public class HashDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{
	
	Hashmap hm1 = new Hashmap();
	
	@SuppressWarnings("unchecked")
	@Override
	public K[] getKeys() {
		return (K[]) hm1.getKeys();
	}

	@SuppressWarnings("unchecked")
	@Override
	public V getValue(K str) {
		return (V) hm1.value((String) str);
	}

	@Override
	public void insert(K key, V value) {
		
		hm1.insert((String)key,(String)value);
		
	}

	@Override
	public void remove(K key) {
		
		hm1.delete((String)key);
		
	}

}
