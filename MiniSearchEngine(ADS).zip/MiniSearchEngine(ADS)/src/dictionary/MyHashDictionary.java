package dictionary;

class Hash
{
	String key;
	String value;
	int count=0;
	
	
	public Hash() {
	}

	Hash(String key, String value) 
	{
		this.key = key;
		this.value = value;
	}
	
	String keys[] = new String[600];
	String val[] = new String[600];
	
	int hashing(String key)
	{
		int index = 0;
		
		for(int i = 0;i < key.length();i++)
		{
			index = index + key.charAt(i);
		}
		index = index % 600;
		
		return index;
	}
	
	void insert(String key,String value)
	{
		int k = hashing(key);
		
		if(keys[k] == null)
		{
			keys[k] = key ;
			val[k] = value;
			count++;
		}
		else
		{
			val[k] = val[k] +"-->"+value;
		}
		
	}
	
	void remove(String key)
	{
		int k = hashing(key);
		
		if(keys[k] != null)
		{
			keys[k] = null;
			val[k] = null;
			count--;
		}
	}
	
	String[] getKeys()
	{
		int j = 0;
		String[] gk = new String[count];
		
		for(int i = 0;i < keys.length;i++)
		{
			if(keys[i] != null)
			{
				gk[j++] = keys[i];
			}
		}
		return gk;
	}
	
	String getValue(String key)
	{
		int k = hashing(key);
		return val[k];
	}
	
}

public class MyHashDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{
	
	Hash h = new Hash();

	@SuppressWarnings("unchecked")
	@Override
	public K[] getKeys() {
		
		return (K[]) h.getKeys();
	}

	@SuppressWarnings("unchecked")
	@Override
	public V getValue(K str) {
		return (V) h.getValue((String)str);
	}

	@Override
	public void insert(K key, V value) {
		
		h.insert((String)key,(String) value);
		
	}

	@Override
	public void remove(K key) {
		
		h.remove((String)key);
		
	}

}
