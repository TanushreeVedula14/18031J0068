package dictionary;

import java.util.ArrayList;


class Node<K extends Comparable<K>, V> 
{
	K key;
	V value;
	Node<K,V> next;
	
	public Node(K key, V value) {
		
		this.key = key;
		this.value = value;
		
	}
 }

class LinkedList<K extends Comparable<K>, V>
{
	    Node<K,V> head;
		String keys[];
		String val[];
		
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		public void insert(K key,V value)
		{
			Node<K,V> n = new Node<K,V>(key,value);				
			if(head == null)
			{
				head = n;
			}
			else
			{	
				Node temp = head,temp1 = null;
				int flag=0;
				while(temp != null)
				{
					if(temp.key.equals(key))
					{   
						flag=1;
						temp.value = temp.value+"-->"+value;
						break;
					}
					temp1 = temp;
					temp = temp.next;
				}
				if(flag == 0)
				{
					temp1.next = n;
				}
			}
		}
		
		public void  remove(K key1)
		{
			
		      Node<K,V> temp = head;
				
		      if(head.key.equals(key1))
		      {
		    	  head = temp.next;
		      }
		      else
		      {
				while(temp.next != null )
				{
					if(temp.next.key.compareTo(key1) == 0)
					{
						temp.next = temp.next.next;
						break;
					}
					temp = temp.next;
				}
		      }
		}
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		public K[] getKeys()
		{	
			int i = 0;
			keys = new String[size()];
			Node temp = head;
			while(temp != null )
			{
				keys[i] = (String) temp.key;
				i++;
				temp = temp.next;
			}
		   return (K[]) keys;
				
		}
		
		@SuppressWarnings("unused")
		public V  get(K key1)
		{
			Node<K,V> temp1 = null;
			
			if(key1  == null)
				
			{
				return null;
			}
			
			else
			{
				Node<K,V> temp = head;
			
				while(temp != null )
				{	
					if(temp.key.compareTo(key1) == 0)
					{
						return (V) temp.value;
					}
					temp = temp.next;
				}
				return null;
			}
		}

		@SuppressWarnings("rawtypes")
		public int size()
		{
			int count=0;
			Node temp1 = head;
			while(temp1 != null)
			{
				temp1 = temp1.next;
				count++;
				
			}
			return count;
		}
}


public class ListDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>
{
	
	@SuppressWarnings("rawtypes")
	LinkedList ll = new LinkedList();
	
	@SuppressWarnings("unchecked")
	@Override
	public K[] getKeys() {
		return (K[]) ll.getKeys();
	}

	@SuppressWarnings("unchecked")
	@Override
	public V getValue(K str) {
		return (V) ll.get((String) str);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void insert(K key, V value) {
		
		ll.insert((String)key,(String) value);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void remove(K key) {
		
		ll.remove((String) key);
		
	}

}
