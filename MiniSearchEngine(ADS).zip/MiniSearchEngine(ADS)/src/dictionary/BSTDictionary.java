package dictionary;

import java.util.ArrayList;

class Node1
{
	String key;
	String value;
	Node1 left,right;

	Node1(String key,String value)
	{
		this.key=key;
		this.value=value;
		left=right=null;	
	}
}

class BST
{	
	int count;
	Node1 root;
	
	BST()
	{
		root = null;
		count = 0;
	}
	
	public void insert(String key,String value)
	{
		count++;
		root = insert(root,key,value);
	}
	private Node1 insert(Node1 root, String key, String value)
	{
		if(root == null)
		{
			return new Node1(key,value);
		}
		
		int cmp = key.compareTo(root.key);
		if(cmp < 0)
		{
			root.left = insert(root.left,key,value);
		}
		else if(cmp > 0)
		{
			root.right = insert(root.right,key,value);
		}
		else
		{
			//root.value = value;
			root.value = root.value +"-->"+ value;
		}
		return root;
	}
	
	String get(String key) 
	{
		return get(root,key);
	}
	String get(Node1 root, String key) 
	{ 
		if (root == null) 
		{
			return null;
		}
		else
		{
			int cmp = key.compareTo(root.key) ;  
			if (cmp < 0) 
			{
				return get(root.left, key);
			}
			else if (cmp > 0)
			{
				return get(root.right, key);
			}
			else 
			{
				return root.value;
			}
		}
	}

	void remove(String key) 
	{ 
		root = remove(root, key); 
	} 
	Node1 remove(Node1 root, String key) 
	{ 
		if (root == null) 
		{
			return root; 
		}
		
		int cmp = key.compareTo(root.key) ; 
		
		if (cmp < 0)
		{
			root.left = remove(root.left, key);
		}
		else if (cmp >0) 
		{
			root.right = remove(root.right, key);
		}
		else
		{	 
			if (root.left == null) 
			{
				return root.right;
			}
			else if (root.right == null)
			{
				return root.left; 
			}
			root.key = minValue(root.right); 
			root.right = remove(root.right, root.key); 
		} 
		return root; 
	} 

	String minValue(Node1 root) 
	{ 
		Node1 min = null;
		
		while (root.left != null) 
		{ 
			min = root.left; 
			root = root.left; 
		} 
		return min.key; 
	}
	
	String[] inorder()
	{
		ArrayList<String> al=new ArrayList<String>();
		
		inorder(root,al);
		int size = al.size();
		String [] str = new String[size];
		for(int i = 0;i < size;i++)
		{
			str[i] = (String)al.get(i);
		}
		return str;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	void inorder(Node1 n,ArrayList al)
	{
	
		if(n != null) 
		{
			inorder(n.left,al);
			al.add(n.key);
			inorder(n.right,al);
		}
	}
}

public class BSTDictionary <K extends Comparable<K>, V> implements DictionaryInterface <K,V>{
	
	BST b=new BST();
	@SuppressWarnings("unchecked")
	@Override
	public K[] getKeys() {
	
		return (K[]) b.inorder();
	}

	@SuppressWarnings("unchecked")
	@Override
	public V getValue(K str) {
		return (V) b.get((String)str);
	}

	@Override
	public void insert(K key, V value) {
	
		b.insert((String)key,(String) value);
	
	}

	@Override
	public void remove(K key) {
	
		b.remove((String)key) ;
	
	}
}

