package com.example.tanushree.leavemanagementsystemproject;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterAuthentication extends AppCompatActivity implements View.OnClickListener {

    private EditText name;
    private EditText rollno;
    private EditText email;
    private EditText password;
    private EditText mentorName;
    private EditText mobNo;
    private Button register;
    private TextView alreadyLogin;

    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_authentication);

        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();

        if(firebaseAuth.getCurrentUser() != null)
        {
            finish();
            startActivity(new Intent(getApplicationContext(),HomePageActivity.class));
        }

        name = (EditText)findViewById(R.id.RAETname);
        rollno = (EditText)findViewById(R.id.RAETRollNo);
        email = (EditText)findViewById(R.id.RAETEMail);
        password = (EditText)findViewById(R.id.RAETPwd);
        mentorName = (EditText)findViewById(R.id.RAETMentor);
        mobNo = (EditText)findViewById(R.id.RAETMobileNo);
        register = findViewById(R.id.buttonRegister);
        alreadyLogin = (TextView)findViewById(R.id.RATVAlreadyLogin);

        register.setOnClickListener(this);
        alreadyLogin.setOnClickListener(this);


    }

    private void registerUser()
    {
        String emailId = email.getText().toString().trim();
        String pwd = password.getText().toString().trim();

        if(TextUtils.isEmpty(emailId))
        {
            Toast.makeText(this,"Enter e-mail id.",Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(pwd))
        {
            Toast.makeText(this,"Enter password",Toast.LENGTH_SHORT).show();
        }

        firebaseAuth.createUserWithEmailAndPassword(emailId,pwd).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    //startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                    Toast.makeText(RegisterAuthentication.this,"Authentication Success",Toast.LENGTH_SHORT).show();
                    return;
                }
                else
                {
                    Toast.makeText(RegisterAuthentication.this,"Failed to Authenticate",Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });

    }

    private void saveUserInformation()
    {
        String roll = rollno.getText().toString().trim();
        String Name = name.getText().toString().trim();
        String emailId = email.getText().toString().trim();
        String mobile = mobNo.getText().toString().trim();
        String mentor = mentorName.getText().toString().trim();

        UserInformation userInformation = new UserInformation(roll,Name,emailId,mobile,mentor);

        FirebaseUser user = firebaseAuth.getCurrentUser();

        databaseReference.child(user.getUid()).setValue(userInformation);

        Toast.makeText(this,"Information Saved....",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {

        if(v == register)
        {
            registerUser();
            if(v == register) {
                saveUserInformation();
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            }
            else
            {
                Toast.makeText(this,"Information didn't saved.",Toast.LENGTH_SHORT).show();
            }
        }

        if(v == alreadyLogin)
        {
            Intent intent = new Intent(RegisterAuthentication.this,LoginActivity.class);
            startActivity(intent);
        }

    }
}
