package com.example.tanushree.leavemanagementsystemproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.w3c.dom.Text;

public class HomePageActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth firebaseAuth;
    private TextView name;
    private TextView email;
    private TextView rollno;
    private TextView mobno;
    private TextView mentorName;
    private TextView leavestaken;

    private Button logout;
    private Button applyLeave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        firebaseAuth = FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser() == null)
        {
            finish();
            startActivity(new Intent(this,LoginActivity.class));
        }

        FirebaseUser user = firebaseAuth.getCurrentUser();

        name = (TextView)findViewById(R.id.HPTVName1);
        email = (TextView)findViewById(R.id.HPTVEMail1);
        rollno = (TextView)findViewById(R.id.HPTVRollNo1);
        mobno = (TextView)findViewById(R.id.HPTVMobNo1);
        mentorName = (TextView)findViewById(R.id.HPTVMentorName1);
        leavestaken = (TextView)findViewById(R.id.HPTVLeavesTaken1);
        logout = findViewById(R.id.buttonLogout);
        applyLeave = findViewById(R.id.buttonApplyLeave);

        logout.setOnClickListener(this);
        applyLeave.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if(v == logout)
        {
            firebaseAuth.signOut();
            finish();
            startActivity(new Intent(this,LoginActivity.class));
        }
    }
}
