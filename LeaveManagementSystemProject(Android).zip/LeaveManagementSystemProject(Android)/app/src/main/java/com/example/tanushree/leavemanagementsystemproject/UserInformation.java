package com.example.tanushree.leavemanagementsystemproject;

import java.util.Random;

public class UserInformation {

    public String rollNo;
    public String name;
    public String email;
    public String mobNo;
    public String mentorName;

    public UserInformation()
    {

    }

    public UserInformation(String rollNo, String name, String email, String mobNo, String mentorName) {
        this.rollNo = rollNo;
        this.name = name;
        this.email = email;
        this.mobNo = mobNo;
        this.mentorName = mentorName;
    }


    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobNo() {
        return mobNo;
    }

    public void setMobNo(String mobNo) {
        this.mobNo = mobNo;
    }

    public String getMentorName() {
        return mentorName;
    }

    public void setMentorName(String mentorName) {
        this.mentorName = mentorName;
    }
}
