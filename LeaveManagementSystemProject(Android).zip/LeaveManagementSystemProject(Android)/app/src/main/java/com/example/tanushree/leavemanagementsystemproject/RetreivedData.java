package com.example.tanushree.leavemanagementsystemproject;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class RetreivedData extends ArrayAdapter<UserInformation>
{
    private Activity context;
    private List<UserInformation> userdata;

    public RetreivedData(Activity context,List<UserInformation> userdata)
    {
        super(context,R.layout.activity_home_page,userdata);
        this.context = context;
        this.userdata = userdata;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.activity_home_page,null,true);

        TextView name = (TextView)listViewItem.findViewById(R.id.HPTVName1);
        TextView email = (TextView)listViewItem.findViewById(R.id.HPTVEMail1);
        TextView rollno = (TextView)listViewItem.findViewById(R.id.HPTVRollNo1);
        TextView mobno = (TextView)listViewItem.findViewById(R.id.HPTVMobNo1);
        TextView mentorName = (TextView)listViewItem.findViewById(R.id.HPTVMentorName1);
        TextView leavestaken = (TextView)listViewItem.findViewById(R.id.HPTVLeavesTaken1);

        UserInformation userInformation = userdata.get(position);

        name.setText(userInformation.getName());
        email.setText(userInformation.getEmail());
        rollno.setText(userInformation.getRollNo());
        mobno.setText(userInformation.getMobNo());
        mentorName.setText(userInformation.getMentorName());

        return listViewItem;
    }
}
