package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable;
import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import in.msitprogram.jntu.paypal.console.PPAccountScreen;



public class Transaction implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String tTime;
	String tDate;
	PPAccount account;
	String narration;
	String reference;
	String status;
	float debit;
	float credit;
	
	DateFormat df = new SimpleDateFormat("dd/MM/yy & HH:mm:ss");
	Date dateobj = new Date();
	//PPAccountScreen ppas = new PPAccountScreen();
	
	public Transaction()
	{
	
	}
	
	
	public Transaction(String tTime, String tDate, PPAccount account, String narration, String reference, String status,
			float debit, float credit) 
	{
		super();
		this.tTime = tTime;
		this.tDate = tDate;
		this.account = account;
		this.narration = narration;
		this.reference = reference;
		this.status = status;
		this.debit = debit;
		this.credit = credit;
		this.df = df;
		this.dateobj = dateobj;
	}


	public String gettTime() {
		return tTime;
	}

	public void settTime(String time) {
		this.tTime = tTime;
	}

	public String gettDate() {
		return tDate;
	}

	public void settDate(String date) {
		this.tDate = tDate;
	}

	public  PPAccount getAccount() {
		return account;
	}

	public  void setAccount(PPAccount account) {
		this.account = account;
	}

	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = "Paypal";
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = "Done";
	}

	public float getDebit()
	{
		return debit;
	}

	public  void setDebit(float debit) {
		this.debit = debit;
	}

	public float getCredit() {
		return credit;
	}

	public void setCredit(float credit) {
		this.credit = credit;
	}

	@Override
	public String toString() {
		return "\n[Date=" + java.time.LocalDate.now() +"Time=" + java.time.LocalTime.now() + "Narration=" + narration
				+ "Reference=" + reference + "Status=" + status + "Debit=" + debit + "Credit=" + credit + "]";
	}

	
	
}
