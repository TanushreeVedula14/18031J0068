package in.msitprogram.jntu.paypal.accounts;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.console.PPAccountActivationScreen;
import in.msitprogram.jntu.paypal.console.PPNewAccountScreen;

public class PPAccount implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Profile profile;
	private String email;
	private float accountBal;
	private boolean isActivated;
	private String activationCode;
	private ArrayList<Transaction> transactions = new ArrayList<Transaction>();
	
	
	PPNewAccountScreen ppnas = new PPNewAccountScreen(email);
	PPAccountActivationScreen ppaas = new PPAccountActivationScreen();
	
	public PPAccount() 
	{
		// TODO Auto-generated constructor stub
		
	}
	public PPAccount(Profile profile,String email) 
	{
		// TODO Auto-generated constructor stub
		super();
		this.profile = profile;
		this.email = email;
		
	}
	
	public void setProfile(Profile profile) 
	{
		this.profile = profile;
	}
	public Profile getProfile() 
	{
		return profile;
	}
	
	public void setAccountBal(float bal) {
		this.accountBal = bal;
	}
	public float getAccountBal() {
		return accountBal;
	}

	public void setActivated(boolean isActivated) {
		this.isActivated = isActivated;
	}
	public boolean isActivated() {
		return isActivated;
	}

	public void setTransactions(Transaction transaction)
	{
		this.transactions.add(transaction);
	}
	public ArrayList<Transaction> getTransactions() 
	{
		return transactions;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public void activate(String activationCode) throws IOException 
	{
		// TODO Auto-generated method stub
	}
	

	public void setActivationCode(String activationCode) throws IOException
	{
		this.activationCode=activationCode;
	}
	
	public String getActivationCode() 
	{
		return activationCode;
	}
	public String toString() 
	{
		// implement this function to return a beautiful looking string
		// to display the summary of the account
		
		return "\n"+profile+"\nEmail:"+email+ 
				"\nIsActivated:"+isActivated+"\nActivationCode:"+activationCode; 
	}
	
	public void suspend() 
	{
		// TODO Auto-generated method stub
		boolean isActivated = false;
	}


	public boolean withdraw(float withdrawAmount) 
	{
		this.accountBal=this.accountBal-withdrawAmount;
		return false;
	}


	public boolean addFunds(float creditAmount) 
	{
		this.accountBal=this.accountBal+creditAmount;
		return false;
	}
	
	public boolean sendMoney(float creditAmount) 
	{
		
		return false;
	}
	
	public boolean requestMoney(float creditAmount) 
	{
		
		return false;
	}

	public String getEmail() 
	{
		// TODO Auto-generated method stub
		return email;
	}
	
	
}
