package in.msitprogram.jntu.paypal.accounts;

public class PPRestrictedAccount extends PPAccount 
{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String parentEmail;
	private float withdrawLimit;
	
	public String getParentEmail() 
	{
		return parentEmail;
	}

	public void setParentEmail(Object object) 
	{
		this.parentEmail = (String) object;
	}

	public float getWithdrawLimit() 
	{
		return withdrawLimit;
	}

	public void setWithdrawLimit(float withdrawLimit) 
	{
		this.withdrawLimit = withdrawLimit;
	}



	public PPRestrictedAccount(Profile profile,String parentEmail)
	{
		super(profile, parentEmail);
		// TODO Auto-generated constructor stub
	}

}
