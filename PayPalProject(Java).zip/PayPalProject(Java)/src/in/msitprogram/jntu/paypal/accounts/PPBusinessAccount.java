package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable;
import java.util.ArrayList;

public class PPBusinessAccount extends PPAccount implements Serializable
{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -6496492152755352738L;
	

	@Override
	public String toString() {
		return "PPBusinessAccount [accountOperators=" + accountOperators + "]";
	}

	private ArrayList <PPRestrictedAccount> accountOperators;

	public PPBusinessAccount(Profile profile,String email) {
		super(profile,email);
		accountOperators=new ArrayList<PPRestrictedAccount>();
		
	}
	public ArrayList<PPRestrictedAccount> operation()
	{
		return accountOperators;
		
	}
	
	public void addAccountOperator(PPRestrictedAccount accountOperator){
		//add account operators after checking if there are duplicates
		for(PPRestrictedAccount pp:accountOperators)
		{
		     if((pp.getEmail()).equals(accountOperator.getEmail()))
		{
			System.out.println("Error");
			return;
		}
		
	}
		accountOperators.add(accountOperator);

	}
}