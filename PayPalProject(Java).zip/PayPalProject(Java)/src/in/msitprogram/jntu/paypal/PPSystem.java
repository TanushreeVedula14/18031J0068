package in.msitprogram.jntu.paypal;

import in.msitprogram.jntu.paypal.console.MainMenu;

public class PPSystem
{
	

	public static void main(String[] args) throws Exception 
	{
		MainMenu.show();
	}

}
