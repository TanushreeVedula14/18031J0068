package in.msitprogram.jntu.paypal.persistance;

import in.msitprogram.jntu.paypal.accounts.PPAccount;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;
public class DataStore
{
	
	@SuppressWarnings("unchecked")
	public static PPAccount lookupAccount(String email) throws Exception
	{
		PPAccount account;
		File file = new File("D:/Java/PayPalProject/src/in/msitprogram/jntu/paypal/javaProject.txt");
		//initialize it after reading from file
		// write code to open the files, read
		if(file.exists())
		{
		FileInputStream fis = new FileInputStream(file);
		@SuppressWarnings("resource")
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Vector<PPAccount> vs;
		vs = (Vector<PPAccount>) ois.readObject();
		for(int i=0;i<vs.size();i++)
		{
			account = vs.get(i);
			if(account.getEmail().equals(email))
			{
				
				return account;
			}
		}
		ois.close();
		}
		
		
		
		return null;
	}
	
	
	
	public static void writeAccount(PPAccount account) throws IOException, ClassNotFoundException
	{
		Vector<PPAccount> vs = new Vector<PPAccount>();
		
		File file = new File("D:/Java/PayPalProject/src/in/msitprogram/jntu/paypal/javaProject.txt");
		
		if(file.exists())
		{
			FileInputStream fis = new FileInputStream(file);
			@SuppressWarnings("resource")
			ObjectInputStream ois = new ObjectInputStream(fis);
			@SuppressWarnings({ "unused", "resource" })
			DataInputStream dis = new DataInputStream(fis);
			vs = (Vector<PPAccount>) ois.readObject();
		
			for(int i=0;i<vs.size();i++)
			{
				//System.out.println(vs.get(i).getEmail()+""+account.getEmail());
				if(vs.get(i).getEmail().equals(account.getEmail()))
				{
					vs.remove(i);
					break;
				}
			}
			vs.add(account);

			FileOutputStream fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(vs);
			
			oos.flush();
			oos.close();
		}
		else
		{
		
			FileOutputStream fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			vs.add(account);
			oos.writeObject(vs);
			System.out.println("Success....\n");
			oos.close();
			
		}
	}
	
}
