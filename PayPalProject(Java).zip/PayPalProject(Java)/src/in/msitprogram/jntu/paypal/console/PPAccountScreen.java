package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.PPRestrictedAccount;
import in.msitprogram.jntu.paypal.accounts.Transaction;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

public class PPAccountScreen implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	PPAccount account = new PPAccount();
	Scanner scan;
	@SuppressWarnings("unused")
	private ArrayList<Transaction> transactions;
	
		
	public PPAccountScreen(String email) throws Exception
	{
		scan = new Scanner(System.in);
		account = DataStore.lookupAccount(email);
	}
	
	Transaction t=new Transaction();
	MainMenu mm = new MainMenu();
	String narration;
	String date;
	String time;
	String status;
	String reference;
	PPToolkit ppt = new PPToolkit();
	
	@SuppressWarnings("static-access")
	public void show() throws Exception
	{
		//check if account is active
		if(account.isActivated())
		{
			System.out.println(account);
			int op;
			do
			{
				System.out.println("1.Credit\n2.Debit\n3.Send Money\n4.Request Money\n5.Transaction Details\n6.Exit");
				System.out.println("Enter any one option");
				@SuppressWarnings("resource")
				Scanner sc = new Scanner(System.in);
				op=sc.nextInt();
				
				switch(op)
				{
					case 1: addFunds();
				  	        break;
					case 2: withdrawFunds();
							break;
					case 3:	sendMoney();
							DataStore.writeAccount(account);
							break;
					case 4:	requestMoney();
							DataStore.writeAccount(account);
							break;
					case 5: ArrayList<Transaction> al=new ArrayList<Transaction>();
			        		al=account.getTransactions();
			        		@SuppressWarnings("rawtypes") 
			        		Iterator i=al.iterator();
			        		System.out.println("***********************************************");
			        		System.out.println("\n Date\t\t Time \t\t Narration \t\t Reference \t\t Status \t\t Credit \t\t Debit ");
			        		while(i.hasNext())
			        		{
			        			System.out.println(i.next());
			        		}
			        		MainMenu.show();
			        		break;
					case 6: mm.show();
							break;
				}
			}while(op<5);
		}
		else
		{
			System.out.println("Activate your Account");
			System.out.println("Do you want to activate your account?");
			System.out.println("1.Yes\n2.No");
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			int ch = sc.nextInt();
			String email;
			switch(ch)
			{
			
			case 1: String generateCode = PPToolkit.generateActivationCode();
					account.setActivationCode(generateCode);
					DataStore.writeAccount(account);
				
					System.out.println("Activation Code:"+generateCode);
					System.out.println("Enter Email");
				  	email = sc.next();
				  	try
				  	{
				  		account = DataStore.lookupAccount(email);
				  		if(account!=null)
				  		{
				  			if(!account.isActivated())
				  			{
				  				int i;
				  				@SuppressWarnings("static-access")
				  				String str=ppt.generateActivationCode();
				  				for(i=0;i<3;i++)
				  				{
				  					System.out.println("You have "+(3-i)+" attempts");
				  					System.out.println("Enter your activation code:");
				  					String ac=sc.next();
				  					if(ac.equals(str))
				  					{
				  						account.setActivated(true);
				  						System.out.println("Your account is activated.");
				  						DataStore.writeAccount(account);
				  						MainMenu.show();
				  					}
				  				}
				  				if(i==3)
				  				{
				  					System.out.println("You tried more than 3 attempts");
				  					MainMenu.show();
				  				}
				  			}
				  		}
				  		else
				  		{
				  			System.out.println("Your account doesnt exists for activation.");
				  			MainMenu.show();
				  		}
				  	}
				  	catch(Exception e)
				  	{
				  		e.printStackTrace();
				  	}
				  	break;
			case 2: System.out.println("Enter Email:");
					email = sc.next();
					try
					{
						account = DataStore.lookupAccount(email);
						if(account!=null)
						{
							if(account.isActivated())
							{
								account.setActivated(false);
								DataStore.writeAccount(account);
								System.out.println("Your account is suspended.");
								MainMenu.show();
							}
						}
						else
						{
							System.out.println("Your account doesn't exists for suspension.");
							MainMenu.show();
						}
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				  	
				}
			}
						
		// print menu and accept menu options
		// for all the paypal account operations
	}


		
		private void withdrawFunds() throws Exception 
		{
			// implement the withdraw funds user interface here
			if(account instanceof PPRestrictedAccount)
			{
				@SuppressWarnings("resource")
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter amount you want to withdraw:");
				float withdrawAmount=sc.nextFloat();
				float bal=account.getAccountBal();
				if(withdrawAmount>6000)
				{
					System.out.println("Limit Exceeds.");
				}
				else
				{
					if(bal>withdrawAmount)
					{
					    account.setAccountBal(account.getAccountBal()-withdrawAmount);
					}
					else
					{
						System.out.println("Insufficient Funds");
						MainMenu.show();
					}
				}
				//account.setAccountBal(account.getAccountBal()+withdrawAmount);
				DataStore.writeAccount(account);
				System.out.println("Balance:"+account.getAccountBal());
			}
			
			scan=new Scanner(System.in);
			System.out.println("Enter amount you want to withdraw:");
			float debit=scan.nextFloat();
			float bal=account.getAccountBal();

			if(bal>debit)
			{
				account.setAccountBal(account.getAccountBal()-debit);
			}
			else
			{
				System.out.println("Insufficient Amount");
			}
			
			
			t.settDate(date);
			t.settTime(time);
			t.setDebit(debit);
			t.setReference(reference);
			t.setAccount(account);
			t.setStatus(status);
			System.out.println(t.toString());
			//transactions.add(t);
			account.setTransactions(t);
			//transactions.add(t);
			/*for (int i = 0; i < transactions.size(); i++) 
			{
				System.out.println(account.getTransactions().get(i));
			}*/
			DataStore.writeAccount(account);
			//use the account object as needed for withdraw funds
			
		}

		private void requestMoney() throws Exception 
		{
			// 	implement the request money user interface here
			
			scan=new Scanner(System.in);
			System.out.println("Enter receiver e-mail:");
			String email = scan.nextLine();
			System.out.println("Enter request money:");
			float req = scan.nextFloat();
			PPAccount account1 = null;
			
			account1 = DataStore.lookupAccount(email);
			LocalDate date = java.time.LocalDate.now();
			String tDate = String.valueOf(date);
			LocalTime time = java.time.LocalTime.now();
			String tTime = String.valueOf(time);
			String narration = "You requested "+req+" rupess.";
			String reference = (String) account.getEmail();
			String reference1 = (String) account1.getEmail();
			String status = "Requested";
			float credit = 0;
			float debit = 0;
			Transaction t = new Transaction(tDate,tTime,account,narration,reference1,status,credit,debit);
			Transaction t1 = new Transaction(tDate,tTime,account1,narration,reference,status,credit,debit);
			ArrayList<Transaction> transactions1 = new ArrayList<>();
			//transactions.add(t);
			//transactions1.add(t1);
			account.setTransactions(t);
			account.setTransactions(t1);
			//transactions.add(t);
			//transactions1.add(t1);
			//System.out.println(t.toString());
			//System.out.println(t1.toString());
			DataStore.writeAccount(account);
			DataStore.writeAccount(account1);
			
			
			//use the account object as needed for request money funds
		}

		private void sendMoney() throws Exception
		{
			// implement the send moeny user interface here
			if(account instanceof PPRestrictedAccount)
			{
				System.out.println("You are not allowed to send money.");
			}
			else
			{
				scan=new Scanner(System.in);
				System.out.println("Enter sender e-mail:");
				String email = scan.nextLine();
				System.out.println("Enter sending money:");
				float req = scan.nextFloat();
				PPAccount account1 = null;
			
				account1 = DataStore.lookupAccount(email);
				LocalDate date = java.time.LocalDate.now();
				String tDate = String.valueOf(date);
				LocalTime time = java.time.LocalTime.now();
				String tTime = String.valueOf(time);
				String narration="sending";
				String reference = (String) account.getEmail();
				String reference1 = (String) account1.getEmail();
				String status = null;
				boolean t = account.withdraw(req);
				if(t==true)
				{
					account1.addFunds(req);
					status="successful";
				}
				else
				{
					System.out.println("Insufficient Funds.");
					status="unsuccessful";
				}
				float debit1=req;
				float credit=0;
				Transaction t1 = new Transaction(tTime,tDate,account,narration,reference1,status,debit1,credit);
				account.setTransactions(t1);
				float debit2=0;
				float credit1=credit;
				Transaction t2 = new Transaction(tTime,tDate,account1,narration,reference,status,debit2,credit1);
				ArrayList<Transaction> transactions2 = new ArrayList<>();
				//transactions.add(t1);
				//transactions2.add(t2);

				account.setTransactions(t2);
				account1.setTransactions(t1);
				account1.setTransactions(t2);
				//System.out.println(t1.toString());
				//System.out.println(t2.toString());
				//transactions.add(t1);
				//transactions.add(t2);
				DataStore.writeAccount(account);
				DataStore.writeAccount(account1);
				System.out.println("Balance:"+account.getAccountBal());
			}
			
			//use the account object as needed for send money funds
		}

		private void addFunds() throws IOException, ClassNotFoundException 
		{
			// implement the add funds user interface here
			if(account instanceof PPRestrictedAccount)
			{
				System.out.println("You are not allowed to credit.");
			}
			else
			{
				scan=new Scanner(System.in);
				System.out.println("Enter amount you want to add:");
				float credit=scan.nextFloat();
				float bal=account.getAccountBal();
				bal=bal+credit;
				account.setAccountBal(account.getAccountBal()+credit);
			
				System.out.println("Balance:"+bal);
				LocalDate date = java.time.LocalDate.now();
				String tDate = String.valueOf(date);
				t.settDate(tDate);
				LocalTime time = java.time.LocalTime.now();
				String tTime = String.valueOf(time);
				t.settTime(tTime);
				t.setCredit(credit);
				t.setReference(reference);
				t.setAccount(account);
				t.setStatus(status);
				//transactions.add(t);
				account.setTransactions(t);
				/*for (int i = 0; i < transactions.size(); i++) 
				{
					System.out.println(account.getTransactions().get(i));
				}*/

				//System.out.println(t.toString());
				DataStore.writeAccount(account);
				//use the account object as needed for add funds
			}
		}

	}
