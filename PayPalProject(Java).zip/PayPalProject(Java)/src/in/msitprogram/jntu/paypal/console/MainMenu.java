package in.msitprogram.jntu.paypal.console;

import java.io.Serializable;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;


public class MainMenu implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	@SuppressWarnings("resource")
	public static void show() throws Exception
	{
		Scanner sc;
		@SuppressWarnings("unused")
		PPAccount ppa;
		PPAccountScreen ppas;
		PPNewAccountScreen ppna;
		String eMail;
		String eMail1;
		@SuppressWarnings("unused")
		String name = null;
		@SuppressWarnings("unused")
		String phone = null;
		@SuppressWarnings("unused")
		String address = null;
		
		//show the welcome message with the main menu options
		System.out.println("*****WELCOME TO PAYPAL*****");
		System.out.println("1.Sign Up.\n2.Sign In.\nEnter your choice ? ");
		sc = new Scanner(System.in);
		int i = sc.nextInt();
		
		switch(i)
		{
			case 1: System.out.println("*****CREATE PAYPAL ACCOUNT*****");
					System.out.println("Enter E-Mail id:");
					eMail = sc.next();
					ppna = new PPNewAccountScreen(eMail);
					ppna.show();
					break;
			case 2: System.out.println("*****SIGN IN*****");
					System.out.println("Enter E-Mail id:");
			 		eMail1 = sc.next();
			 		ppas = new PPAccountScreen(eMail1);
			 		ppas.show();
					break;
		}
		
		//take the menu option as input from the console
		
		//take email address as input from the console
		
		//based on the given menu option instantiate the respective screens
	}

}
