package in.msitprogram.jntu.paypal.console;

import java.io.Serializable;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

public class PPAccountActivationScreen implements Serializable
{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("resource")
	public static void show() throws Exception 
	{
		Scanner sc;
		PPAccount account = new PPAccount();
		PPToolkit ppt = new PPToolkit();
		String email = "";//change to get console input
		
		System.out.println("1.Activate.\n2.Suspend");
		System.out.println("Enter your choice:");
		sc = new Scanner(System.in);
		int ch = sc.nextInt();
		
		switch(ch)
		{
			case 1:	System.out.println("Enter Email");
					email=sc.next();
					try
					{
						account = DataStore.lookupAccount(email);
						if(account!=null)
						{
							if(!account.isActivated())
							{
								int i;
								@SuppressWarnings("static-access")
								String str=ppt.generateActivationCode();
								for(i=0;i<3;i++)
								{
									System.out.println("You have "+(3-i)+" attempts");
									System.out.println("Enter your activation code:");
									String ac=sc.next();
									if(ac.equals(str))
									{
										account.setActivated(true);
										System.out.println("Your account is activated.");
										DataStore.writeAccount(account);
										MainMenu.show();
									}
								}
								if(i==3)
								{
									System.out.println("You tried more than 3 attempts");
									MainMenu.show();
								}
							}
						}
						else
						{
							System.out.println("Your account doesnt exists for activation.");
							MainMenu.show();
						}
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					break;
			case 2: System.out.println("Enter Email:");
			  		email = sc.next();
			  		try
			  		{
			  			account = DataStore.lookupAccount(email);
			  			if(account!=null)
				          {
					        if(account.isActivated())
					        {
					        	account.setActivated(false);
					        	DataStore.writeAccount(account);
					        	System.out.println("Your account is suspended.");
					        	MainMenu.show();
					        }
				         }
				        else
				        {
				        	System.out.println("Your account doesn't exists for suspension.");
				        	MainMenu.show();
				        }
			  		}
			  		catch(Exception e)
			  		{
			  			e.printStackTrace();
			  		}
			  		break;
		}
		
		/*
		 * TODO
		 * fetch the account object using email address
		 * check if the account is suspended
		 * if suspended then activate it
		 * if activation code invalid, retry for 2 more attempts
		 * on successful activation show main menu
		 * on failure show the error message and continue to main menu
		 */		
		
		
		
		
		//check if account is active. if yes then ask for suspending it
		
		// if yes suspend it if not go back to main menu
		
		// accept activation code, check if valid, if not give 2 more attempts
		
		//proceed to main menu
		MainMenu.show();
	
	}

}