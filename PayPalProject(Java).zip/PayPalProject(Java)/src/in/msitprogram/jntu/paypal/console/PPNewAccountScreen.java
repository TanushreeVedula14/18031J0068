package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.PPBusinessAccount;
import in.msitprogram.jntu.paypal.accounts.PPRestrictedAccount;
import in.msitprogram.jntu.paypal.accounts.Profile;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

public class PPNewAccountScreen implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Profile profile;
	PPAccount account;
	PPRestrictedAccount ppra;
	String email;
	
	PPToolkit ppt;
	String activationCode;
	String generateCode;
	PPAccountActivationScreen ppaas;
	
	public PPNewAccountScreen(String email) 
	{
		
		profile = new Profile();
		this.email = email;
	}

	@SuppressWarnings("static-access")
	public void show() throws Exception 
	{
		//check if the account with the given email address exists
		MainMenu mm = null;
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		try
		{
			account = DataStore.lookupAccount(email);
			if(account==null)
			{
				createProfile();
				System.out.println("Select Account Type:");
				System.out.println("1.Personal.\n2.Student.\n3.Business");
				System.out.println("Enter your choice?");
				scan = new Scanner(System.in);
				int ch = scan.nextInt();
				switch(ch)
				{
					case 1: createPersonalAccount();
							break;
					case 2: createStudentAccount();
							break;
					case 3: createBusinessAccount();
							break;
				}
			}
			else
			{
				System.out.println("E-Mail already exist.");
				mm.show();
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
			
		//if not create the user profile
		
		
		//show the account types
		
		
		//based on the given account type selected create the account object
	}

	private Profile createProfile() 
	{
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
				// use this for creating the profile
				System.out.println("Enter Name:");
				String name=scan.next();
				profile.setName(name);
				System.out.println("Enter Phone No:");
				String phone=scan.next();
				profile.setPhone(phone);
				System.out.println("Enter Address:");
				String address=scan.next();
				profile.setAddress(address);
		
				return profile;
	}

	@SuppressWarnings("unused")
	private void createBusinessAccount() throws Exception
	{
		//use this for creating the business account
		Scanner sc = new Scanner(System.in);
        account=new PPBusinessAccount(profile,email);
		account.setActivated(false);
		account.addFunds(10000);
		System.out.println("Enter how many accounts do you needed");
		int x=sc.nextInt();
		
		/*for(int i=0;i<x;i++)
		{
			System.out.println("Enter Employee Email");
			String email2=sc.next();
			PPRestrictedAccount ba=new PPRestrictedAccount(profile, email2);
			
			if(ppra!=null)
			{
				//i--;
				account =DataStore.lookupAccount(email2);
				System.out.println("This mail already Exist. Try another");
			}
			else
			{
				profile=createProfile();
				ppra = new PPRestrictedAccount(profile,email2);
				ppra.setActivated(true);
				//account1.getAccountBal()=
				((PPBusinessAccount) account).addAccountOperator(ppra);
				DataStore.writeAccount(ppra);
			}
		}*/
		
		completeAccountCreation();
}


	@SuppressWarnings("unused")
	private void createStudentAccount() throws Exception 
	{
		//use this for creating the student account
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter parent Email");
		String parentemail=sc.next();
		account =DataStore.lookupAccount(parentemail);
		if(account==null)
		{
			System.out.println("Invalid parent Email");
		}
		else
		{
			ppra=new PPRestrictedAccount(profile,email);
			ppra.setParentEmail(account.getEmail());
			ppra.setWithdrawLimit(5000);
			ppra.setActivated(false);
			ppra.addFunds(0);
			account=ppra;
			completeAccountCreation();
			
		}

		
		
	}

	/*
	 * this method create the personal account, saves it to the file system
	 * and redirects the users to the next screen
	 */
	private void createPersonalAccount() throws Exception 
	{
		Scanner scan=new Scanner(System.in);
		
				System.out.println("*****PERSONAL PAYPAL ACCOUNT*****");
				scan = new Scanner(System.in);
				account = new PPAccount(profile,email);
				account.setEmail(email);
				account.setAccountBal(0.0f);
				account.setActivated(false);
				account.addFunds(0);
				completeAccountCreation();
			
			//use this for creating the personal account
			
		
	}
	
	@SuppressWarnings("static-access")
	private void completeAccountCreation() throws Exception
	{
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		
		String generateCode = PPToolkit.generateActivationCode();
		account.setActivationCode(generateCode);
		DataStore.writeAccount(account);
			
		System.out.println("Activation Code:"+generateCode);
		System.out.println("\n1.Activation Screen.\n2.MainMenu");
		int ch = sc.nextInt();
		
		switch(ch)
		{
			case 1:	PPAccountActivationScreen ppaas=new PPAccountActivationScreen();
					ppaas.show();
					break;
			case 2:	MainMenu.show();
		       		break;
		}
		
		//generate activation code and set it to account
		
		//send activation code to the phone
		
		//ask & redirect the user to the activation screen or the main menu
		
	}
}
