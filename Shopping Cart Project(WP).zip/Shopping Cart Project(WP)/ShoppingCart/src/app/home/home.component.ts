import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AddProductsService } from '../services/add-products.service';
import { mimeType } from './mime-type.validator';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  title = 'Shopping Cart';
  imagePreview:string;
  addProductsForm: FormGroup;

  constructor(private _router: Router, private add: AddProductsService) { }

  ngOnInit() {
    this.addProductsForm = new FormGroup({
      productName: new FormControl(null, [Validators.required]),
      productPrice: new FormControl(null, [Validators.required]),
      productDiscountPrice: new FormControl(null, [Validators.required]),
      image: new FormControl(null, [Validators.required],[mimeType])
    })
  }

  upload()
  {

    console.log("form image===> "+ this.addProductsForm.value.image);

    this.add.uploadProduct(
      this.addProductsForm.value.productName,
      this.addProductsForm.value.productPrice,
      this.addProductsForm.value.productDiscountPrice,
      this.addProductsForm.value.image)
    .subscribe(
      data => {
        alert("Product added successfully "+data);
        this._router.navigate(['/clothes']);
        console.log(data);
      },
      error => {
        alert("Error in adding product");
        console.log(error);
      }
    )
    
  }

  onImagePicked(event:Event){

    const file=(event.target as HTMLInputElement).files[0];
    this.addProductsForm.patchValue({image:file});
    this.addProductsForm.get('image').updateValueAndValidity();
    console.log(file);
    console.log(this.addProductsForm);
    const reader=new FileReader();
    reader.onload=()=>{
      this.imagePreview = reader.result as string;
    };
    reader.readAsDataURL(file);
  
  }

} 
