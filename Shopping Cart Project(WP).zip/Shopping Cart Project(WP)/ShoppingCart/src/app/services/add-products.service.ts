import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class AddProductsService {

  constructor(private http: HttpClient, private router: Router) { }

  uploadProduct(productName:string,productPrice:string,productDiscountPrice:string,image:File)
  {

    const addData = new FormData();
    addData.append('productName',productName);
    addData.append('productPrice',productPrice);
    addData.append('productDiscountPrice',productDiscountPrice);
    addData.append('image',image,productName);

    console.log("register service form data===> "+ JSON.stringify(addData));
    return this.http.post('http://localhost:7000/add/create',addData);
  }

  getProducts()
  {
    console.log("getting data with image.")
    return this.http.get('http://localhost:7000/add/read', 
    {
      headers: new HttpHeaders().append('Content-Type','application/json')
    });
  }

  viewCartProducts(image:any)
  {
    alert(image)
    return this.http.post('http://localhost:7000/addToCart/create',image,
    {
      headers: new HttpHeaders().append('Content-Type','application/json')
    });

 
  }
}
