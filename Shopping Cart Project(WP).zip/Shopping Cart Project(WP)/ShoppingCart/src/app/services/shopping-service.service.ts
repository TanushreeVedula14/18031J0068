import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ShoppingServiceService {

  constructor(private http: HttpClient) { }

  ngOnInit()
  {

  }
  
  registerPost(body: any)
  {
    //alert(body);
    return this.http.post('http://localhost:7000/create', body, {
      observe: 'body',
      headers: new HttpHeaders().append('Content-Type','application/json')
    });
  }

  validateLogin(email,password)
  {
    return this.http.get('http://localhost:7000/read/'+email+'/'+password, 
    {
      headers: new HttpHeaders().append('Content-Type','application/json')
    });
  }
}
