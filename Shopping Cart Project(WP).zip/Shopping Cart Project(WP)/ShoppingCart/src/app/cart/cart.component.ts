import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddProductsService } from '../services/add-products.service';
import { CartItems } from '../Entity/CartItems';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  title = 'Shopping Cart';

  private Items : CartItems[];

  constructor(private _router: Router, private cart: AddProductsService) { }

  ngOnInit() {
    this.cart.getProducts()
    .subscribe(
      data=>
      {
        console.log(data)
        this.Items = data['msg'];
      });
  }

}
