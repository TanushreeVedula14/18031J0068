import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ShoppingServiceService } from '../services/shopping-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup = new FormGroup({
    firstName: new FormControl(null, [Validators.required]),
    lastName: new FormControl(null, [Validators.required]),
    email: new FormControl(null, [Validators.email ,Validators.required]),
    password: new FormControl(null, [Validators.required, Validators.minLength(6)]),
    confirmPassword: new FormControl(null, [Validators.required, Validators.minLength(6)])
  })

  constructor(private _router: Router, private shoppingService: ShoppingServiceService) { }

  ngOnInit() {
  }

  moveToLogin()
  {
    this._router.navigate(['/login']);
  }

  register()
  {  
    if(!this.registerForm.controls.firstName.value)
    {
      alert("Enter first name.");
      return;
    }
    if(!this.registerForm.controls.lastName.value)
    {
      alert("Enter last name.");
      return;
    }  
    if(!this.registerForm.controls.email.value)
    {
      alert("Enter e-mail id.");
      return;
    }
    if(!this.registerForm.controls.password.value)
    {
      alert("Enter password.");
      return;
    }
    if(!this.registerForm.controls.confirmPassword.value)
    {
      alert("Enter confirm password.");
      return;
    }
    if(this.registerForm.controls.password.value != this.registerForm.controls.confirmPassword.value)
    {
      alert("Password and confirm password doesn't match.");
      return;
    }
    //console.log(this.registerForm.value);
    this.shoppingService.registerPost(this.registerForm.value)
    .subscribe(
      data => {
        alert("Registration successfull and data inserted.");
        this._router.navigate(['/login']);
        console.log(data);
      },
      error => {
        alert("Error in Data Inserting.");
        console.log(error);
      }
    )
    
  }

}
