import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ShoppingServiceService } from '../services/shopping-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  loginForm: FormGroup = new FormGroup({
    email: new FormControl(null, [Validators.email, Validators.required]),
    password: new FormControl(null, [Validators.required, Validators.minLength(6)])
  });

  private formSubmitAttempt: boolean;
  constructor(private _router: Router, private shoppingService: ShoppingServiceService) { }

  ngOnInit() {
  }

  moveToRegister()
  {
    this._router.navigate(['/register']);
  }

  login()
  {
    // login validations
    if(!this.loginForm.controls.email.valid)
    {
      alert("Enter email id.");
      console.log('Enter email id');
      return;
    }
    if(!this.loginForm.controls.password.valid)
    {
      alert("Enter password.");
      console.log('Enter password');
      return;
    }
    if(this.loginForm.controls.email.value == 'tanu@gmail.com')
    {
      this.shoppingService.validateLogin(this.loginForm.controls.email.value, this.loginForm.controls.password.value )
      .subscribe(
      data => {
        console.log(data);
        var a = data['msg'];
        console.log(a.length);
        if(a.length == 0)
        {
          alert('Invalid username or password.')
        }
        else
        {
          console.log('Welcome admin.')
          this._router.navigate(['/home']);
        }
        this.formSubmitAttempt = true; 
      },
      error => {
        alert("Error in login.");
        console.log(error);
      })
    }
    else
    {
      console.log(this.loginForm.value);

      this.shoppingService.validateLogin(this.loginForm.controls.email.value, this.loginForm.controls.password.value )
      .subscribe(
        data => {
          console.log(data);
          var a = data['msg'];
          console.log(a.length);
          if(a.length == 0)
          {
            alert('Invalid username or password.')
          }
          else
          {
            console.log
            this._router.navigate(['/clothes']);
          }
        },
        error => {
          alert("Error in login.");
          console.log(error);
        })
    }

    
    
  }

}
