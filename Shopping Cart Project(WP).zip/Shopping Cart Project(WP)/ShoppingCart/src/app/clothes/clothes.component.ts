import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddProductsService } from '../services/add-products.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Products } from '../Entity/Products';

@Component({
  selector: 'app-clothes',
  templateUrl: './clothes.component.html',
  styleUrls: ['./clothes.component.css']
})
export class ClothesComponent implements OnInit {

  image:any={}
  title = 'Shopping Cart';
  showProductsForm:FormGroup = new FormGroup({
    productName: new FormControl(null, [Validators.required]),
    productPrice: new FormControl(null, [Validators.required]),
    productDiscountPrice: new FormControl(null, [Validators.required]),
    image: new FormControl(null, [Validators.required])
  })

  private Product : Products[];
  
  constructor(private _router: Router, private shop: AddProductsService) { }

  ngOnInit() {
    this.shop.getProducts()
    .subscribe(
      data=>
      {
        console.log(data)
        this.Product = data['msg'];
      });
  }

  uploadCart(data)
  {
    this.image.name=data.productName;
    this.image.price=data.productDiscountPrice;
    this.image.path=data.imagePath;
    console.log('Upload Cart')
    this.shop.viewCartProducts(this.image)
    .subscribe(
      data => {
        alert("Product added to cart successfully.");
        console.log(data);
      },
      error => {
        console.log(error);
      })
  }
}
