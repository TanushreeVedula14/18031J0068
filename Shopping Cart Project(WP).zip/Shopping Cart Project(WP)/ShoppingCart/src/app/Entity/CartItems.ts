export class CartItems{
    public productName: String;
    public productDiscountPrice: String;
    public imagePath: File;    
}