export class Products{
    public _id?:String;
    public productName: String;
    public productPrice: String;
    public productDiscountPrice: String;
    public imagePath: File
}