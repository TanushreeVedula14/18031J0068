var express = require('express');
var router = express.Router();
var Register = require('../models/dataSchema');
var Product=require('../models/productSchema');
var Cart = require('../models/cartSchema');
var multer = require('multer');
var MIME_TYPE_MAP = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/jpg": "jpg"
  };
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      console.log('in storage');
      const isValid = MIME_TYPE_MAP[file.mimetype];
      console.log('in storage'+file);
      let error = new Error("Invalid mime type");
      if (isValid) {
        error = null;
      }
      cb(error, "ShoppingCart/images");
    },
    filename: (req, file, cb) => {
      const name = file.originalname
        .toLowerCase()
        .split(' ')
        .join('-');
      const ext = MIME_TYPE_MAP[file.mimetype];
      cb(null, name + "-" + Date.now() + "." + ext);
    }
  });

// add and get products from admin

router.post('/add/create', multer({storage: storage}).single("image"),(req, res, next) => {
    console.log("hello data adding")
    const url = req.protocol + '://' + req.get("host");
    console.log( req.body.productName);
    console.log( req.body.productPrice);
    console.log( req.body.productDiscountPrice);
    console.log( req.body.imagePath);

    const post = new Product({
        productName: req.body.productName,
        productPrice: req.body.productPrice,
        productDiscountPrice: req.body.productDiscountPrice,
        imagePath: url+'/images/'+req.file.filename
    });
    post.save().then(createdPost => {
        res.status(200).json({
            message: "Product added successfully.",
            post: {
                id: createdPost._id,
                productName: createdPost.productName,
                productPrice: createdPost.productPrice,
                productDiscountPrice: createdPost.productDiscountPrice,
                imagePath: createdPost.imagePath 
            }
        });
    });
});

router.get('/add/read',(req, res, next) => {
    console.log("hello data retreive")
    Product.find({ }, (err, register) => {
        if(err)
            res.status(500).json({errmsg: err});
        if(register)
            res.status(200).json({msg: register});
            
       });    
});

//add and get data to cart
router.post('/addToCart/create',(req, res, next) => {
    console.log("Hello Cart(appRoutes.js)");
    console.log( req.body.name);
    console.log( req.body.price);
    console.log( req.body.path);


    var cart = new Cart({
        productName: req.body.name,
        productDiscountPrice: req.body.price,
        imagePath: req.body.path
    });
    cart.save().then(createdCart => {
        res.status(200).json({
            message: "Product added successfully in cart.",
            cart: {
                id: createdCart._id,
                productName: createdCart.productName,
                productDiscountPrice: createdCart.productDiscountPrice,
                imagePath: createdCart.imagePath 
            }
        });
    });
});

router.get('/addToCart/read',(req, res, next) => {
    console.log("Data retreive(appRoute.js)")
    Cart.find({ }, (err, register) => {
        if(err)
            res.status(500).json({errmsg: err});
        if(register)
            res.status(200).json({msg: register});
        });    
});

//login and register users

router.post('/create',(req, res, next) => 
{
    console.log("hello register");
    var newRegister = new Register({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
        confirmPassword: req.body.confirmPassword
    });

    newRegister.save((err, register) => {
        if(err)
            res.status(500).json({errmsg: err});
        res.status(200).json({msg: register});
    });
});

router.get('/read/:p1/:p2',(req, res, next) => {
    console.log("hello login")
    Register.find({email:req.params.p1,password:req.params.p2}, (err, register) => {
        
        if(err)
            res.status(500).json({errmsg: err});
        if(register)
            res.status(200).json({msg: register});
            
       });    
});

router.put('/update',(req, res, next) => {
    Register.findById(req.body._id,(err, register) => {
        if(err)
            res.status(500).json({errmsg: err});
        register.firstName = req.body.firstName;
        register.lastName = req.body.lastName;
        register.eMail = req.body.eMail;
        register.password = req.body.password;
        register.confirmPassword = req.body.confirmPassword;

        register.save((err, register) => 
        {
            if(err)
                res.status(500).json({errmsg: err});
            res.status(200).json({msg: register});
        });
    })
});

router.delete('/delete/:id',(req, res, next) => {
    Register.findOneAndDelete({_id:req.params._id}, (err, register) =>
    {
        if(err)
            res.status(500).json({errmsg: err});
        res.status(200).json({msg: register});
    });
});

module.exports = router;