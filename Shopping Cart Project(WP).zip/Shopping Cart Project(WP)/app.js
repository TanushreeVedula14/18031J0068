var http = require('http');
var express = require('express');
var port = process.env.PORT || 7000;
var app = express();
var appRoutes = require('./routes/appRoute');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var cors=require('cors');
var path = require('path');

mongoose.connect('mongodb://localhost/shoppingCartDb',{ useNewUrlParser: true });
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true}));
app.use("/images", express.static(path.join("ShoppingCart/images")));

app.use(bodyParser.json());
app.use('/',appRoutes);

http.createServer(app).listen(port);
console.log("Backend running on port : ",port);