var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var cartSchema = mongoose.Schema({
    productName: String,
    productDiscountPrice: String,
    imagePath: String
});

module.exports = mongoose.model('addToCart',cartSchema);