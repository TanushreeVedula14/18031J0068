var mongoose = require('mongoose');
var Schema = mongoose.Schema;
// var bcrypt = require('bcrypt');

var productSchema = mongoose.Schema({
    productName: String,
    productPrice: String,
    productDiscountPrice: String,
    imagePath: String
});

module.exports = mongoose.model('addProduct',productSchema);